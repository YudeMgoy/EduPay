<?php $__env->startSection('link'); ?>
    <?php echo e(url('home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">  
    <?php if(!count($item)): ?>  
        <div class="belum-box">
            <img src="<?php echo e(asset('img/belanja.png')); ?>" alt="">
            <h6>Oops keranjang kosong lurr!</h6>            
            <p>Ayo belanja barang - barang pakai DIMON untuk harga yang lebih murah</p>
            <a  class=" button"href="<?php echo e(url('/list/barang')); ?>">MULAI BELANJA!</a>
        </div>        
    <?php else: ?>
        <nav class="bottom-nav">
            <div class="nav-list">
                <div class="nav-box biaya">
                    <h4>Total Rp <?php echo e(number_format($harga,2,',','.')); ?></h4>            
                </div>        
                <a href="#" onclick="beliModul()" class="beli-button button">BELI</a>        
            </div>
        </nav>
        <h3 class="title">
            Keranjang
        </h3>
        <?php if(session()->has('status')): ?>
            <div class="alert alert-success">
                <strong>Sukses!</strong> <?php echo e(session('status')); ?>

            </div>                        
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <strong>Oopss!!</strong> <?php echo e(session('error')); ?>

            </div>                        
        <?php endif; ?>
        <div class="keranjang-container">
        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
            <div class="keranjang-box">
                <a class="x orange" href="<?php echo e(url('hapus/barang')); ?>/<?php echo e($collection->id); ?>">X</a>
                <div class="keranjang-body">
                    <div class="img-box">
                        <img src="<?php echo e(asset($collection->get_barang->img)); ?>" alt="" class="bg-image">
                        <img src="<?php echo e(asset($collection->get_barang->img)); ?>" alt="">
                    </div>
                    <div class="right-box">
                        <h4><?php echo e($collection->get_barang->nama_barang); ?></h4>
                        <form method="POST" action="<?php echo e(url('edit/keranjang')); ?>">
                            <?php echo csrf_field(); ?>                        
                            <input type="number" name="jumlah_barang" id="" value="<?php echo e($collection->jumlah_barang); ?>">
                            <input type="hidden" name="id" value="<?php echo e($collection->id); ?>">                            
                            <button type="submit" class="button">Edit</button>                                
                        </form>
                        <div class="bayar-box" style="margin-top: 5px;">
                            <p style="font-size: 0.9em">Harga</p>
                            <p style="margin: auto !important;margin-right: 0 !important;font-size: 0.9em;">Rp <?php echo e(number_format($collection->harga_barang,2,',','.')); ?><p>
                        </div>                        
                    </div>                                        
                </div>
            </div>                                
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>  

        <div class="form modul" id="beli-modul">            
            <div class="layout" onclick="beliModul()"></div>
            <form action="<?php echo e(url('prosess/beli')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-container">
                    <div class="form-title">
                        <h4>Ayo Beli Lurr!</h4>
                        <a class="x" href="#" onclick="beliModul()" style="color: white !important;">X</a>
                    </div>
                    <div class="form-box">
                        <label for="">Metode</label>
                        <select name="pay" id="metode">
                            <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($i->id); ?>"><?php echo e($i->pay); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-box saldo" id="saldo">
                        <label for="">Saldo Kamu</label>
                        <p style="margin-bottom:0" class="saldo-text">Rp <?php echo e(Auth::user()->saldo); ?></p>
                    </div>
    
                    <div class="form-box cod" id="cod">
                        <label for="">Ketemuan Dimana</label>
                        <select name="alamat_kelas" id="">
                            
                            <option value="Lapangan Basket">Lapangan Basket Sebelah Utara</option>
                        </select>
                    </div>
                    <div class="form-box cod">
                        <label for="">No Whatsapp mu</label>
                        <input type="number" name="no_wa" id="" required placeholder="Yang Aktif ya">
                    </div>
                    
                    <div class="form-box bayar">
                        
                        <div class="bayar-box  total">
                            <p>Total</p>
                            <p>Rp <?php echo e(number_format($harga,2,',','.')); ?></p>
                        </div>
                    </div>
                    <div class="form-box">
                            <button class="button">BAYAR</button>
                    </div>      
                </div>                          
            </form>
        </div>
    <?php endif; ?>
</div>

<script>
modul = document.getElementById("beli-modul");

function beliModul(){
    modul.classList.toggle("modul-active");
}
</script>

<script>
$("#saldo").show();
$(document).ready(function(){    
    $('#metode').on('change', function() {
        if ( this.value == '1')      
        {
            $("#saldo").show();
            $("#cod").show();
        }
        else
        {
            $("#saldo").hide();
            $("#cod").show();
        }
    });
});                    

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/beli/keranjang.blade.php ENDPATH**/ ?>
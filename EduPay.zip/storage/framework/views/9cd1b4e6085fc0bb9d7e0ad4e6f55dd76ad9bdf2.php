<?php $__env->startSection('content'); ?>
    <div class="container-top-up">
        <h5>
            Yukk pergi ke EDU Mart untuk top up saldo!
        </h5>
        <p>Ini nih syaratnya : </p>
        <ul>
            <li>Minimal top up Rp 10.000,00</li>
            <li>Datang ke Edu Mart dan bilang ke kasir</li>
            <li>Tunjukin ID User kalian</li>                        
            <li>Cek apakah saldo sudah bertambah</li>
            <li>Pastikan pakai duit punya kalian sendiri</li>            
        </ul>

        <img src="<?php echo e(asset('img/topupbg.png')); ?>" alt="" class="top-up-bg">
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link'); ?>
    <?php echo e(url('/')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/public/topup.blade.php ENDPATH**/ ?>
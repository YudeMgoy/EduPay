<?php $__env->startSection('home'); ?>
    active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="orange-bg">
    </div>
    <div class="header-container">
        <div class="saldo-box box">
            <div class="box-head">
                <h5>Saldo</h5>
            </div>
            <div class="box-body saldo-body">
                <h3>Rp <div class="duit"><?php echo e(number_format(Auth::user()->saldo,2,',','.')); ?></div></h3>
                <a href="<?php echo e(url("topup")); ?>" class="top-up button">TOP UP</a>
            </div>                    
        </div>
    </div>
    <div class="promo-container">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item active">
                    <a href="<?php echo e(url('promo')); ?>/<?php echo e($promo->id); ?>"><img class="d-block w-100" src="<?php echo e(asset($promo->cover)); ?>" alt="First slide"></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="belanja-container">
        <div class="search-box">
            <form action="<?php echo e(url('search/barang')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="search" placeholder="Ayo cari sesuatu">
                <button class="button">Search</button>                
            </form>
        </div>

        <div class="barang-container">
            <div class="barang-wrapper">
                <div class="barang-header">
                    <h4>Rekomendasi</h4>
                    <a href="<?php echo e(url('list/barang')); ?>" class="lihat">Lihat Semua</a>
                </div>

                <div class="barang-list">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->diskon == NULL): ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url('detail/barang')); ?>/<?php echo e($item->id); ?>">
                            <div class="image-box">
                                <img src="<?php echo e(asset($item->img)); ?>" alt="" class="bg-image">
                                <img src="<?php echo e(asset($item->img)); ?>" alt="">
                            </div>
            
                            <h3><?php echo e(str_limit($item->nama_barang,16)); ?></h3>
                            <div class="harga">
                                    <p class="harga-palsu">Rp <?php echo e(number_format($item->harga_barang,2,',','.')); ?></p>
                                    
                            </div>
                        </a>                
                    </div>
                    <?php else: ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url("detail/barang/$item->id")); ?>">                                                        
                            <div class="image-box">
                                <p class="diskon"><?php echo e(($item->diskon/$item->harga_barang)*100); ?>%</p>
                                <img src="<?php echo e(asset($item->img)); ?>" alt="">
                            </div>
                            <h3><?php echo e(str_limit($item->nama_barang,16)); ?></h3>
                            <div class="harga">                                
                                <p class="harga-palsu">Rp <?php echo e(number_format($item->harga_barang - $item->diskon,2,',','.')); ?></p>
                                <p class="harga-asli">Rp <?php echo e(number_format($item->harga_barang,2,',','.')); ?></p>
                            </div>                            
                        </a>                
                    </div>    
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>                
            </div>            
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="barang-wrapper">
                <div class="barang-header">
                    <h4><?php echo e($row->kategori); ?></h4>
                    <a href="<?php echo e(url('list/barang')); ?>/<?php echo e($row->id); ?>" class="lihat">Lihat Semua</a>
                </div>
                <div class="barang-list">
                    <?php $__currentLoopData = $row->get_barang_data->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php if($data->diskon == NULL): ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url('detail/barang')); ?>/<?php echo e($data->id); ?>">
                            <div class="image-box">
                                <img src="<?php echo e(asset($data->img)); ?>" alt="" class="bg-image">
                                <img src="<?php echo e(asset($data->img)); ?>" alt="">
                            </div>
            
                            <h3><?php echo e(str_limit($data->nama_barang,16)); ?></h3>
                            <div class="harga">
                                    <p class="harga-palsu">Rp <?php echo e(number_format($data->harga_barang,2,',','.')); ?></p>
                                    
                            </div>
                        </a>                
                    </div>
                    <?php else: ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url("detail/barang/$data->id")); ?>">                                                        
                            <div class="image-box">
                                <p class="diskon"><?php echo e(($data->diskon/$data->harga_barang)*100); ?>%</p>
                                <img src="<?php echo e(asset($data->img)); ?>" alt="">
                            </div>
                            <h3><?php echo e(str_limit($data->nama_barang,16)); ?></h3>
                            <div class="harga">                                
                                <p class="harga-palsu">Rp <?php echo e(number_format($data->harga_barang - $data->diskon,2,',','.')); ?></p>
                                <p class="harga-asli">Rp <?php echo e(number_format($data->harga_barang,2,',','.')); ?></p>
                            </div>                            
                        </a>                
                    </div>    
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>            
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/home.blade.php ENDPATH**/ ?>
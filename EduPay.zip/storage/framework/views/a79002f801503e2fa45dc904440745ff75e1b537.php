<?php $__env->startSection('content'); ?>
<h3>Pesanan anda</h3>
<?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h6>Pesanan anda</h6>
    <div class="card">
        <div class="card-header">
            Pembeli : <?php echo e(Auth::user()->name); ?>

            <br>
            dipesan pada : <?php echo e($item->created_at); ?>

            <br>
            Status       : <?php echo e($item->get_status->status); ?>

            <br>
            <a href="<?php echo e(url('detail/pesanan')); ?>/<?php echo e($item->id); ?>">Lihat Detail</a>
        </div>
    <div class="card-body">
    </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/beli/pesanan.blade.php ENDPATH**/ ?>
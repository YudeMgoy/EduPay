<?php $__env->startSection('barang'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="conteiner-fluid">
    <table class="table">
                <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                <?php endif; ?>
        <thead class="bg-orange">
            <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Barang</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->nama_barang); ?></td>
                    <td>
                        <a href="<?php echo e(url("edit/view/$item->id")); ?>"class="orange">Edit</a>
                        <a href="<?php echo e(url('delete/item')); ?>/<?php echo e($item->id); ?>" class="orange">Hapus</a>
                        <a href="<?php echo e(url('kosong/item')); ?>/<?php echo e($item->id); ?>" class="orange">Kosong</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
        </tbody>

            <td colspan="3" onclick="showModul()" style="text-align:center"><a class="btn button" href="#">+ TAMBAH BARANG</a></td>    
        </table>
        <?php echo e($barang->links()); ?>         
    </div>

    <table class="table">
                <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                <?php endif; ?>
            <h4>Barang yang kosong</h4>
        <thead class="bg-orange">
            <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Barang</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kosong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->nama_barang); ?></td>
                    <td>
                        <a href="<?php echo e(url('ada')); ?>/<?php echo e($item->id); ?>" class="orange">Adakan Stok</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
        </tbody>
        </table>      
    </div>

    <div class="form modul" id="beli-modul">            
        <div class="layout" onclick="showModul()"></div>
        <form action="<?php echo e(url('add/barang')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-container">
                <div class="form-title">
                    <h4>Tambah Barang</h4>
                    <a class="x" href="#" onclick="showModul()" style="color: white !important;">X</a>
                </div>
    
                <div class="form-box">
                    <label for="">Nama</label>
                    <input type="text" name="nama" id="" placeholder="Nama/Merk Barang">
                </div>
    
                <div class="form-box">
                    <label for="">Kategori</label>
                    <select name="kategori" id="">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>"><?php echo e($data->kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
    
                <div class="form-box">
                    <label for="">Deskripsi Barang</label>
                    <textarea name="des" id=""></textarea>
                </div>
    
                <div class="form-box">
                    <label for="">Gambar</label>
                    <input type="file" name="img">
                </div>
                <div class="form-box">
                    <label for="">Harga / Satuan</label>
                    <div class="multiform">
                        <input class="input" type="number" placeholder="Rp 10.000,00" name="harga">
                        <select class="input" name="satuan" id="">
                            <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->satuan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>                
                </div>
                <div class="form-box ">
                    <label for="">Diskon/Pengurangan Harga</label>                
                    <input class="input" type="number" placeholder="Rp 10.000,00 boleh kosong kok" name="diskon">                
                </div>
                <div class="form-box">
                        <button class="button" type="submit">TAMBAH</button>
                </div>      
            </div>                      
        </form>
    </div>
        
    
    <script>
    modul = document.getElementById("beli-modul");
    
    function showModul(){
        modul.classList.toggle("modul-active");
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/listbarang.blade.php ENDPATH**/ ?>
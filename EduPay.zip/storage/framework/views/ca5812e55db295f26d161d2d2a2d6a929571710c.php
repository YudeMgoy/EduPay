<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('TopUp')); ?></div>
                <div class="card-body">
                    <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <strong>Oopps!!!</strong> <?php echo e(session('error')); ?>

                    </div>                        
                    <?php endif; ?> 
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('topup')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('ID User')); ?></label>
                            <div class="col-md-6">
                                <input id="id" type="text" class="form-control <?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="id" value="<?php echo e(old('id')); ?>" required autocomplete="id" autofocus>
                                <?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nominal')); ?></label>

                            <div class="col-md-6">
                                <input id="nominal" type="number" class="form-control <?php if ($errors->has('Nominal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Nominal'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nominal" required autocomplete="nominal">

                                <?php if ($errors->has('nominal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nominal'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('TopUp')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/Topup.blade.php ENDPATH**/ ?>
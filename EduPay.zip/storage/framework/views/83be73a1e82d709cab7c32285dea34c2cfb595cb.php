<?php $__env->startSection('content'); ?>
    

    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edu-PayM')); ?></div>

                <div class="card-body">
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('editbarang')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Barang')); ?></label>
                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e($data->nama_barang); ?>" required autocomplete="nama" autofocus>
                                <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="kategori" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kategori')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="exampleFormControlSelect1" name="kategori">
                                    <option>--------Pilih Kategori---------</option>
                                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"<?php if($item->id == $data->kategori): ?>)
                                        selected="selected"
                                            <?php endif; ?>><?php echo e($item->kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="img" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gambar')); ?></label>
                            <div class="col-md-6">
                                <input id="img" type="file" class="form-control <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="img" value="<?php echo e(old('img')); ?>" autocomplete="img" autofocus>
                                <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Harga Barang / Satuan')); ?></label>

                            <div class="col-md-6">
                                <input id="harga" type="number" class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga" required autocomplete="harga" value="<?php echo e($data->harga_barang); ?>">

                                <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Diskon')); ?></label>

                            <div class="col-md-6">
                                <input id="harga" type="number" class="form-control <?php if ($errors->has('diskon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('diskon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="diskon" required autocomplete="diskon" value="<?php echo e($data->diskon); ?>">

                                <?php if ($errors->has('diskon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('diskon'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Deskripsi')); ?></label>

                            <div class="col-md-6">
                                <textarea name="des" id="" cols="20" rows="5" class="form-control <?php if ($errors->has('des')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('des'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><?php echo e($data->deskripsi); ?></textarea>
                                <?php if ($errors->has('des')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('des'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="kategori" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Satuan')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="exampleFormControlSelect1" name="satuan">
                                    <option>--------Pilih Kategori---------</option>
                                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($satuans->id); ?>"<?php if($satuans->id == $data->satuan): ?>)
                                        selected="selected"
                                            <?php endif; ?>><?php echo e($satuans->satuan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('satuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('satuan'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Edit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/edit.blade.php ENDPATH**/ ?>
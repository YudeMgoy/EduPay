<?php $__env->startSection('link'); ?>
    <?php echo e(url('riwayat')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="bottom-nav">
    <div class="nav-list">
        <div class="nav-box biaya">
            <h4>Total Rp <?php echo e($detail->total_harga); ?>,00</h4>            
        </div>
        <?php if($detail->status == 2 || $detail->status == 1): ?>
            <a href="<?php echo e(url('terima/barang')); ?>/<?php echo e($detail->id); ?>" class="beli-button button">Terima</a>
            <a href="<?php echo e(url('batal/beli')); ?>/<?php echo e($detail->id); ?>" class="beli-button button">Batal</a>
        <?php elseif($detail->status == 4 || $detail->status == 3): ?>        
            <a href="<?php echo e(url('hapus/transaksi')); ?>/<?php echo e($detail->id); ?>" class="beli-button button">Hapus</a>       
        <?php endif; ?>        
    </div>
</nav>
<div class="container">
    <h3 class="title">
        Transaksi
    </h3>
    <div class="keranjang-container">
        <?php $__currentLoopData = $detail->get_keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="keranjang-box">            
            <div class="keranjang-body">
                <div class="img-box">
                    <img src="<?php echo e(asset($data->get_barang->img)); ?>" alt="">
                </div>
                <div class="right-box">
                    <h4><?php echo e($data->get_barang->nama_barang); ?> x (<?php echo e($data->jumlah_barang); ?>)</h4>
                    <div class="bayar-box" style="margin-top: 5px;">
                        <p style="font-size: 0.9em">Harga</p>
                        <p style="margin: auto !important;margin-right: 0 !important;font-size: 0.9em;">Rp <?php echo e($data->get_barang->harga_barang - $data->get_barang->diskon); ?>,00<p>
                    </div>                        
                </div>                                        
            </div>
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/beli/transaksi.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edu-PayM')); ?></div>

                <div class="card-body">
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('editpromo')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($promo->id); ?>">
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('judul')); ?></label>
                            <div class="col-md-6">
                                <input id="judul" type="text" class="form-control <?php if ($errors->has('Judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Judul'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="judul" value="<?php echo e($promo->judul); ?>" required autocomplete="nama" autofocus>
                                <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Banner')); ?></label>
                            <div class="col-md-6">
                                <input id="banner" type="file" class="form-control <?php if ($errors->has('Banner')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Banner'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="banner" autocomplete="nama" autofocus>
                                <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Isi')); ?></label>
                            <div class="col-md-6">
                                <textarea name="isi" id="" cols="30" rows="5" class="form-control <?php if ($errors->has('isi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('isi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><?php echo e($promo->isi); ?></textarea>
                                <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kode Promo')); ?></label>
                            <div class="col-md-6">
                                <input id="kode_promo" type="text" value="<?php echo e($promo->kode_promo); ?>" class="form-control <?php if ($errors->has('kode_promo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kode_promo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="kode_promo"  autocomplete="kode_promo" autofocus>
                                <?php if ($errors->has('kode_promo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kode_promo'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nominal')); ?></label>
                            <div class="col-md-6">
                                <input id="nominal" type="number" value="<?php echo e($promo->nominal_promo); ?>" class="form-control <?php if ($errors->has('nominal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nominal'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nominal" autocomplete="nominal" autofocus>
                                <?php if ($errors->has('nominal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nominal'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tanggal Berakhir')); ?></label>
                            <div class="col-md-6">
                                <input id="tanggal_berakhir" type="date" value="<?php echo e($promo->tanggal_berakhir); ?>" class="form-control <?php if ($errors->has('tanggal_berakhir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_berakhir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="tanggal_berakhir" required autocomplete="tanggal_berakhir" autofocus>
                                <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Edit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/editpromo.blade.php ENDPATH**/ ?>
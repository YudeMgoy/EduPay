<?php $__env->startSection('title'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="splash" id="splash">
    <img src="<?php echo e(asset('img/dimon-logo-4.png')); ?>" alt="">
    <p>v 0.0.1</p>
</div>
<div class="container">
    <div class="login-box">                
        <div class="main-title">
            <img src="<?php echo e(asset('img/dimon-logo.png')); ?>" alt="">            
        </div>
        <div class="login-body">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NIS')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="number" class="form-control <?php if ($errors->has('nis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nis'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nis" value="<?php echo e(old('nis')); ?>" required autocomplete="email" autofocus>

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row forgot-box">                    
                    <button type="submit" class="btn button">
                        <?php echo e(__('Login')); ?>

                    </button>

                    <div class="forgot">
                        <?php if(Route::has('password.request')): ?>
                            <a class="btn btn-link" href="<?php echo e(url('lupa')); ?>">
                                <?php echo e(__('Lupa Kata Sandi?')); ?>

                            </a>
                        <?php endif; ?>
                    </div>                                            
                </div>

                
            </form>
        </div>
    </div>            
</div>

<script>
let splash = document.getElementById('splash');

setTimeout(function(){
    splash.classList.add("opacity0");
},3000);

setTimeout(function(){
    splash.classList.add('hidden');
}, 3300);;
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/auth/login.blade.php ENDPATH**/ ?>
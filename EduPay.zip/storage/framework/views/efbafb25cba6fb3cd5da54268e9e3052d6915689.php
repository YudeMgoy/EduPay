<?php $__env->startSection('content'); ?>
<h2>Detail Pesanan
</h2>
<div class="card">
    <div class="card-header">
        Pesanan <?php echo e($detail->status); ?>

    </div>
    <div class="card-body">
            <div class="barang">
                <h6>List barang yang di beli</h6>
                <?php $__currentLoopData = $detail->get_keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($data->get_barang->nama_barang); ?>

                <?php echo e($data->get_barang->harga_barang); ?>

                /kg
                <br>
                <h6>
                    Jumlah Barang : <?php echo e($data->jumlah_barang); ?>

                </h6>
                <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h6>
                    Total Bayar :   <?php echo e($detail->total_harga); ?>

                </h6>
    </div>
    <a href="<?php echo e(url('terima/barang')); ?>">Di terima</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/beli/detail_pesanan.blade.php ENDPATH**/ ?>
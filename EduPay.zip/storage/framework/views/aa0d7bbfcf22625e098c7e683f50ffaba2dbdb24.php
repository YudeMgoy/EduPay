<?php $__env->startSection('barang'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="conteiner-fluid">
    <table class="table">
                <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                <?php endif; ?>
        <thead class="bg-orange">
            <tr>
            <th scope="col">No</th>
            <th scope="col">Kategori</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->kategori); ?></td>
                    <td>
                        <a href="<?php echo e(url("edit/kategori/view/$item->id")); ?>"class="orange">Edit</a>
                        <a href="<?php echo e(url('hapus/kategori')); ?>/<?php echo e($item->id); ?>" class="orange">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
        </tbody>
            <td colspan="3" onclick="showModul()" style="text-align:center"><a class="btn button" href="#">+ TAMBAH Kategori</a></td>    
        </table>        
    </div>

    <div class="form modul" id="beli-modul">            
        <div class="layout" onclick="showModul()"></div>
        <form action="<?php echo e(url('add/kategori')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-container">
                <div class="form-title">
                    <h4>Tambah Kategori</h4>
                    <a class="x" href="#" onclick="showModul()" style="color: white !important;">X</a>
                </div>
    
                <div class="form-box">
                    <label for="">Nama</label>
                    <input type="text" name="kategori" id="" placeholder="Kategori" required>
                </div>

                <div class="form-box">
                        <button class="button" type="submit">TAMBAH</button>
                </div>      
            </div>                      
        </form>
    </div>
        
    
    <script>
    modul = document.getElementById("beli-modul");
    
    function showModul(){
        modul.classList.toggle("modul-active");
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/listkategori.blade.php ENDPATH**/ ?>
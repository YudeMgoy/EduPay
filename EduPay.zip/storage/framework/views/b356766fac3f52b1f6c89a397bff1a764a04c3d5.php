<?php $__env->startSection('pesanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keranjang'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link'); ?>
    <?php echo e(url('/')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="title">
            Daftar Pesanan
    </h4>
    <div class="list-pesanan">
        <?php if(session()->has('status')): ?>
            <div class="alert alert-success">
                <strong>Sukses!</strong> <?php echo e(session('status')); ?>

            </div>                        
        <?php endif; ?>
        
        <?php
            $index =0;
        ?>                    
        <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
            <div class="pesanan-box">                
                <div class="pesanan-header" onclick="showBody(<?php echo $index ?>)">
                    <h4><?php echo e($transaksi->get_barang->name); ?> : <?php echo e($transaksi->id_transaksi); ?></h4>
                    <i class="fa fa-caret-down"></i>
                    <span class="fa fa-caret-down"></span>
                </div>
                <div class="pesanan-body">                     
                    <div class="barang-pesanan-list">
                        
                        <?php $__currentLoopData = $transaksi->get_keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keranjang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="barang-pesanan-box">
                            <h4><?php echo e($keranjang->get_barang->nama_barang); ?></h4>
                            <div class="bottom">
                                <p><?php echo e(number_format(($keranjang->get_barang->harga_barang-$keranjang->get_barang->diskon), 2, ',','.')); ?> (<?php echo e($keranjang->jumlah_barang); ?>)</p>
                                <?php if($transaksi->status == 1): ?>
                                <?php if($keranjang->jumlah_barang == 1): ?>
                                 <a href="<?php echo e(url('barang/kosong')); ?>/<?php echo e($keranjang->id); ?>" class="orange">Kosong</a>
                                <?php else: ?>
                                <div class="form modul" id="beli-modul">            
                                    <div class="layout" onclick="showModul()"></div>
                                    <form action="<?php echo e(url('edit/stock')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id_keranjang" value="<?php echo e($keranjang->id); ?>">
                                        <div class="form-title">
                                            <h4>edit</h4>
                                            <a class="x" href="#" onclick="showModul()" style="color: white !important;">X</a>
                                        </div>
                                        <div class="form-box cod">
                                            <label for="">Jumlah yang tersedia</label>
                                            <input type="number" name="jumlah_stock" id="">
                                        </div>
                                        <div class="form-box">
                                                <button class="button">Edit</button>
                                        </div>                
                                    </form>
                                </div>
                                <a href="#" class="orange" onclick="showModul()">edit</a>   
                                <?php endif; ?>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                                                                                        
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>                                    
                </div>

                <div class="pesanan-footer">
                    <div class="status">
                        <p>Metode : <?php echo e($transaksi->get_pay->pay); ?></p>
                        <p class="<?php echo e($transaksi->get_status->style); ?>"><?php echo e($transaksi->get_status->status); ?></p>
                    </div>
                    <div class="status">
                        <p>WA : <a href="https://api.whatsapp.com/send?phone=<?php echo e(Str::replaceFirst('0', '62', $transaksi->no_wa)); ?>&text=Halo%20<?php echo e($transaksi->get_barang->name); ?>%20Silahkan%20ambil%20Pesanan%20kamu"><?php echo e($transaksi->no_wa); ?></a></p>
                    </div>
                    <div class="status">
                        <p>Tempat : <?php echo e($transaksi->alamat_kelas); ?></p>
                    </div>                                        
                    <div class="status" style="margin-bottoM: 10px;">
                        <h6>Total Bayar</h6>
                        <h6>Rp <?php echo e(number_format($transaksi->total_harga, 2, ',','.')); ?> </h6>                                                
                    </div>                   
                    <?php if($transaksi->status == 1): ?>
                        <a href="<?php echo e(url('dikirim')); ?>/<?php echo e($transaksi->id); ?>" class="text-secondary">Kirim</a>   
                    <?php elseif($transaksi->status ==3): ?>
                        <a href="#" class="text-success">Selesai</a>   
                    <?php elseif($transaksi->status == 4): ?>
                        <a href="<?php echo e(url('hapus/transaksi')); ?>/<?php echo e($transaksi->id); ?>" class="text-danger">Hapus</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php
                $index++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div> 

<script>
    bodies = document.getElementsByClassName("pesanan-body");

    function showBody(index){        
        bodies[index].classList.toggle('pesanan-body-active');
    }
</script>
<script>
modul = document.getElementById("beli-modul");

function showModul(){
    modul.classList.toggle("modul-active");
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/gudang/gudanglist.blade.php ENDPATH**/ ?>
<?php if(count($errors)): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <strong>Gagal!</strong> <?php echo e($error); ?>

        </div>      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\Edi\EduPay\resources\views/layouts/error.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <nav class="bottom-nav">
        <?php if($barang->stok != NULL): ?>
        <form action="<?php echo e(url("add/keranjang/$barang->id")); ?>" method="POST">
        <div class="nav-list">            
                <?php echo csrf_field(); ?>
                <div class="nav-box no-padding">
                    <input type="number" name="jumlah_barang" placeholder="Jumlah" disabled>
                </div>                
                <div class="no-padding">
                    <button class="button" disabled>Habis</button>
                </div>                            
        </div>
    </form>
        <?php else: ?>
    <form action="<?php echo e(url("add/keranjang/$barang->id")); ?>" method="POST">
        <div class="nav-list">            
                <?php echo csrf_field(); ?>
                <div class="nav-box no-padding">
                    <input type="number" name="jumlah_barang" placeholder="Jumlah">
                </div>                
                <div class="no-padding">
                    <button class="button">TAMBAH</button>
                </div>                            
        </div>
    </form>
        <?php endif; ?>
    </nav>
    <div class="detail-container">
        <?php if($barang->diskon == NULL): ?>
        <div class="image-box">
            
            <img src="<?php echo e(asset($barang->img)); ?>" alt="" class="bg-image">
            <img src="<?php echo e(asset($barang->img)); ?>" alt="">
        </div>

        <div class="info-box">
            <h3><?php echo e($barang->nama_barang); ?></h3>
            <div class="harga">                                
                    <p class="harga-palsu">Rp <?php echo e(number_format($barang->harga_barang,2,',','.')); ?></p>
            </div>                                
        </div>  
        
        <div class="deskripsi-box">
            <h4>Deskripsi Barang</h4>
            <p><?php echo e($barang->deskripsi); ?></p>
        </div>    
        <?php else: ?>
        <div class="image-box">
            <p class="diskon-detail"><?php echo e(($barang->diskon/$barang->harga_barang)*100); ?>%</p>
            <img src="<?php echo e(asset($barang->img)); ?>" alt="" class="bg-image">
            <img src="<?php echo e(asset($barang->img)); ?>" alt="">
        </div>
        <div class="info-box">
            <h3><?php echo e($barang->nama_barang); ?></h3>
            <div class="harga">                                
                    <p class="harga-palsu">Rp <?php echo e(number_format($barang->harga_barang - $barang->diskon,2,',','.')); ?></p>
                    <p class="harga-asli">Rp <?php echo e(number_format($barang->harga_barang,2,',','.')); ?></p>
            </div>                                
        </div>  
        
        <div class="deskripsi-box">
            <h4>Deskripsi Barang</h4>
            <p><?php echo e($barang->deskripsi); ?></p>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link'); ?>
    <?php echo e(url('/')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.nonav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/barang/detailbarang.blade.php ENDPATH**/ ?>
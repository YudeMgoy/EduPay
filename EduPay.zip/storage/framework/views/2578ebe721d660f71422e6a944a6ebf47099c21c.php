<?php $__env->startSection('riwayat'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="title">
        Riwayat
    </h3>
    
    <div class="keranjang-container">
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="keranjang-box">     
            <a href="<?php echo e(url('detail/pesanan')); ?>/<?php echo e($item->id); ?>">
                <div class="keranjang-body">                
                    <div class="full-box">
                        <h4 class="<?php echo e($item->get_status->style); ?>"><?php echo e($item->get_status->status); ?></h4>
                        <div class="bayar-box" style="margin-top: 5px;">
                            <p style="font-size: 0.9em">Total</p>
                            <p style="margin: auto !important;margin-right: 0 !important;font-size: 0.9em;">Rp <?php echo e(number_format($item->total_harga, 2,',','.')); ?><p>
                        </div>
                        <div class="bayar-box" style="margin-top: 5px;">
                            <p style="font-size: 0.9em">Tempat</p>
                            <p style="margin: auto !important;margin-right: 0 !important;font-size: 0.9em;"><?php echo e($item->alamat_kelas); ?><p>
                        </div>
                        <p class="date"><?php echo e($item->created_at->diffForHumans()); ?></p>                 
                    </div>                                        
                </div>
            </a>                   
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>      
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/public/riwayat.blade.php ENDPATH**/ ?>
<?php $__env->startSection('akun'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="top-container">
        <div class="img-box">
            <img src="<?php echo e(Auth::user()->img); ?>" alt="" class="bg-image">
            <img src="<?php echo e(Auth::user()->img); ?>" alt="">
        </div>

        <h4><?php echo e(Auth::user()->name); ?></h4>
        <p><span STYLE="font-size: 0.8em;">ID : </span> <?php echo e(Auth::user()->id_user); ?></p>
        
    </div>

    <div class="bottom-container">
        <?php if(Auth::user()->role == 1): ?>
        <div class="bottom-box">
            <a href="<?php echo e(url('promosi')); ?>">Promo</a>       
        </div>
        <div class="bottom-box">
            <a href="<?php echo e(url('kategori/view')); ?>">Kategori</a>       
        </div>
        <div class="bottom-box">
            <a href="#" onclick="showModul()">Top Up</a>       
        </div>
        <?php else: ?>
            <?php if(Auth::user()->role == 2): ?>
        <div class="bottom-box">
            <a href="<?php echo e(url('topup')); ?>">Saldo</a>
            <p>Rp.<?php echo e(Auth::user()->saldo); ?></p>
        </div>
        <div class="bottom-box">
            <a href="<?php echo e(url('riwayat')); ?>">Pesanan</a>       
        </div> 
            <?php else: ?>
                
            <?php endif; ?>
        <?php endif; ?>
        <div class="bottom-box">
            <a href="<?php echo e(url('pengaturan')); ?>">Pengaturan</a>            
        </div>
        <div class="bottom-box">
            <a class="orange" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

    <div class="form modul" id="beli-modul">            
        <div class="layout" onclick="showModul()"></div>
        <form action="<?php echo e(url('topup/prosess')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-title">
                <h4>Top Up User!</h4>
                <a class="x" href="#" onclick="showModul()" style="color: white !important;">X</a>
            </div>

            <div class="form-box cod">
                <label for="">ID User</label>
                <input type="text" name="id" id="">
            </div>

            <div class="form-box cod">
                <label for="">Jumlah</label>
                <input type="number" name="nominal" id="">
            </div>
            <div class="form-box">
                    <button class="button">TOP UP</button>
            </div>                
        </form>
    </div>    

<script>
modul = document.getElementById("beli-modul");

function showModul(){
    modul.classList.toggle("modul-active");
}
</script>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/public/akun.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edu-PayM')); ?></div>

                <div class="card-body">
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(session('status')); ?>

                    </div>                        
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('editkategori')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($kategori->id); ?>">
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kategori')); ?></label>
                            <div class="col-md-6">
                                <input id="kategori" type="text" class="form-control <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="kategori" value="<?php echo e($kategori->kategori); ?>" required autocomplete="nama" autofocus>
                                <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Edit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/admin/editkategori.blade.php ENDPATH**/ ?>
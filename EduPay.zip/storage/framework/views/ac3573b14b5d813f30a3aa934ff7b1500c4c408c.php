<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/list.css')); ?>">  
    <title><?php echo e(config('app.name', 'Edu-PayM')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/keranjang.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">
</head>
<body>
    <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <nav class="bottom-nav">
            <div class="nav-list">
                <?php if(Auth::user()->role == 1): ?>

                <div class="nav-box <?php echo $__env->yieldContent('barang'); ?>">
                    <a href="<?php echo e(url('view/all/barang')); ?>">
                        <img src="<?php echo e(asset("img/keranjang.png")); ?>" alt="">
                        <p>Kelola Barang</p>
                    </a>                    
                </div>

                <div class="nav-box <?php echo $__env->yieldContent('akun'); ?>">
                    <a href="<?php echo e(url('akun')); ?>">
                        <img src="<?php echo e(asset("img/akun.png")); ?>" alt="">
                        <p>Akun</p>
                    </a>
                </div>
                <?php else: ?>
                <?php if(Auth::user()->role == 2): ?>
                <div class="nav-box <?php echo $__env->yieldContent('home'); ?>">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset("img/home.png")); ?>" alt="">
                        <p>Home</p>
                    </a>
                </div>

                <div class="nav-box <?php echo $__env->yieldContent('riwayat'); ?>">
                    <a href="<?php echo e(url('riwayat')); ?>">
                        <img src="<?php echo e(asset("img/history.png")); ?>" alt="">
                        <p>Riwayat</p>
                    </a>                    
                </div>
                
                <div class="nav-box <?php echo $__env->yieldContent('keranjang'); ?>">
                    <a href="<?php echo e(url('keranjang')); ?>">
                        <img src="<?php echo e(asset("img/keranjang.png")); ?>" alt="">
                        <p>Keranjang</p>
                    </a>                    
                </div>

                <div class="nav-box <?php echo $__env->yieldContent('akun'); ?>">
                    <a href="<?php echo e(url('akun')); ?>">
                        <img src="<?php echo e(asset("img/akun.png")); ?>" alt="">
                        <p>Akun</p>
                    </a>
                </div>
                <?php else: ?>
                <div class="nav-box <?php echo $__env->yieldContent('pesanan'); ?>">
                    <a href="<?php echo e(url('gudang/list')); ?>">
                        <img src="<?php echo e(asset("img/history.png")); ?>" alt="">
                        <p>List Pesanan</p>
                    </a>                    
                </div>

                <div class="nav-box <?php echo $__env->yieldContent('akun'); ?>">
                    <a href="<?php echo e(url('akun')); ?>">
                        <img src="<?php echo e(asset("img/akun.png")); ?>" alt="">
                        <p>Akun</p>
                    </a>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </nav>

        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH D:\Edi\EduPay\resources\views/layouts/app.blade.php ENDPATH**/ ?>
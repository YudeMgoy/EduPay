<?php $__env->startSection('link'); ?>
    <?php echo e(url('/home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="banner-box">
        <img src="<?php echo e(asset($data->cover)); ?>" alt="" class="bg-image">
        <img src="<?php echo e(asset($data->cover)); ?>" alt="">
        <div class="layout"></div>
        <h4><?php echo e($data->judul); ?></h4>
    </div>

    <div class="deskripsi-box">
        <h4>Deksripsi</h4>
        <p><?php echo e($data->isi); ?></p>
    </div>

    <p class="date-promo">Berakhir pada <?php echo e($data->tanggal_berakhir); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/public/detailpromo.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container-top-up">
        <h5>
            Wahh lupa password-mu ya?
        </h5>
        <p> Yuk ikuti petunjuk di bawah,</p>
        <ul>
            <li>Pergi ke admin di Edumart</li>
            <li>Meminta untuk reset password</li>
            <li>Masukan NIS untuk password sementara</li>              
        </ul>

        <img class="lupa"src="<?php echo e(asset('img/lupa.png')); ?>" alt="" class="top-up-bg">
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link'); ?>
    <?php echo e(url('/')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/public/lupa.blade.php ENDPATH**/ ?>
<?php $__env->startSection('link'); ?>
    <?php echo e(url('/home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    List Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('barang'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="title"><?php echo e($kategori); ?></h3>
            <?php if(session()->has('status')): ?>
                <div class="alert alert-success">
                    <strong>Success!</strong> <?php echo e(session('status')); ?>

                </div>                        
            <?php endif; ?>
    <div class="barang-noscroll">
        <div class="search-box">
            <form action="<?php echo e(url('search/barang')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="search" placeholder="Ayo cari sesuatu">
                <button class="button">Search</button>                
            </form>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($item->diskon == NULL): ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url('detail/barang')); ?>/<?php echo e($item->id); ?>">
                            <div class="image-box">
                                <img src="<?php echo e(asset($item->img)); ?>" alt="" class="bg-image">
                                <img src="<?php echo e(asset($item->img)); ?>" alt="">
                            </div>
            
                            <h3><?php echo e(str_limit($item->nama_barang,16)); ?></h3>
                            <div class="harga">
                                    <p class="harga-palsu">Rp <?php echo e(number_format($item->harga_barang,2,',','.')); ?></p>
                                    
                            </div>
                        </a>                
                    </div>
                    <?php else: ?>
                    <div class="barang-box">
                        <a href="<?php echo e(url("detail/barang/$item->id")); ?>">                                                        
                            <div class="image-box">
                                <p class="diskon"><?php echo e(($item->diskon/$item->harga_barang)*100); ?>%</p>
                                <img src="<?php echo e(asset($item->img)); ?>" alt="">
                            </div>
                            <h3><?php echo e(str_limit($item->nama_barang,16)); ?></h3>
                            <div class="harga">                                
                                <p class="harga-palsu">Rp <?php echo e(number_format($item->harga_barang - $item->diskon,2,',','.')); ?></p>
                                <p class="harga-asli">Rp <?php echo e(number_format($item->harga_barang,2,',','.')); ?></p>
                            </div>                            
                        </a>                
                    </div>    
                    <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>Oopps Barang tidak di temukan</h3><a href="<?php echo e(url('list/barang')); ?>">Lihat Semua barang?</a>
        <?php endif; ?>         
    </div>
</div>
<hr>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Edi\EduPay\resources\views/beli/listbarang.blade.php ENDPATH**/ ?>